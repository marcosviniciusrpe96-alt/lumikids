import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "wouter";
import { toast } from "sonner";
import {
  ArrowLeft,
  ArrowRight,
  Award,
  BarChart3,
  Bell,
  BookOpen,
  Brain,
  Check,
  ChevronRight,
  CircleHelp,
  Clock3,
  Edit3,
  Flame,
  Gamepad2,
  Globe2,
  GraduationCap,
  Headphones,
  Heart,
  Home as HomeIcon,
  Lightbulb,
  LockKeyhole,
  Menu,
  Music2,
  Palette,
  Pencil,
  Plus,
  RotateCcw,
  Settings2,
  Sparkles,
  Star,
  Trophy,
  Volume2,
  X,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { rewardForLevel } from "../../../shared/lumina";

const MASCOT = "/manus-storage/lumina-mascot_fa321dec.png";

type View = "inicio" | "explorar" | "perfil" | "professor";
type Level = "Iniciante" | "Médio" | "Avançado";
type Student = { id: string; name: string; avatar: string; points: number; stars: number; progress: number; streak: number };
type Activity = { id: string; prompt: string; visual: string; options: string[]; answer: string; sound?: string; trace?: string };

type Subject = {
  key: string;
  label: string;
  subtitle: string;
  icon: typeof BookOpen;
  color: string;
  soft: string;
  activity: string;
  progress: number;
};

const subjects: Subject[] = [
  { key: "alfabetizacao", label: "Alfabetização", subtitle: "Letras e palavras", icon: BookOpen, color: "#ed7358", soft: "#fff0eb", activity: "Complete a palavra", progress: 90 },
  { key: "matematica", label: "Matemática", subtitle: "Contar e descobrir", icon: BarChart3, color: "#4b8df8", soft: "#edf4ff", activity: "Sequência numérica", progress: 70 },
  { key: "logica", label: "Raciocínio lógico", subtitle: "Pense diferente", icon: Brain, color: "#a26be8", soft: "#f5eeff", activity: "Qual peça falta?", progress: 80 },
  { key: "criatividade", label: "Criatividade", subtitle: "Imagine e crie", icon: Palette, color: "#f1ae40", soft: "#fff6df", activity: "Colorir o jardim", progress: 60 },
  { key: "ingles", label: "Inglês", subtitle: "Hello, colors!", icon: Globe2, color: "#35b896", soft: "#e9fbf4", activity: "Find the color", progress: 70 },
  { key: "musica", label: "Música e sons", subtitle: "Ouça e dance", icon: Music2, color: "#e2659c", soft: "#ffeff7", activity: "Qual instrumento?", progress: 45 },
  { key: "ciencias", label: "Ciências", subtitle: "O mundo lá fora", icon: Lightbulb, color: "#5ab8c9", soft: "#e8f9fb", activity: "Pequenos cientistas", progress: 55 },
  { key: "caligrafia", label: "Caligrafia", subtitle: "Trace e escreva", icon: Pencil, color: "#e97d9c", soft: "#fff0f4", activity: "Traços divertidos", progress: 60 },
];

const avatars = ["🧑‍🚀", "🧙", "🧑‍🔬", "🦸", "🐱", "🐶", "🦊", "🐼", "🦁", "🐰"];
const levels: { name: Level; color: string; icon: string; note: string }[] = [
  { name: "Iniciante", color: "#31b777", icon: "●", note: "Vamos começar" },
  { name: "Médio", color: "#f1ae40", icon: "●", note: "Mais um desafio" },
  { name: "Avançado", color: "#ed7358", icon: "●", note: "Você consegue" },
];

const defaultStudent: Student = { id: "luna", name: "Luna", avatar: "🦊", points: 1240, stars: 48, progress: 72, streak: 4 };
const initialStudents: Student[] = [
  defaultStudent,
  { id: "tom", name: "Tomás", avatar: "🧑‍🚀", points: 980, stars: 36, progress: 58, streak: 2 },
  { id: "bibi", name: "Bibi", avatar: "🐼", points: 1540, stars: 62, progress: 86, streak: 7 },
];

function readStudents() {
  try {
    const stored = localStorage.getItem("lumina-students");
    return stored ? (JSON.parse(stored) as Student[]) : initialStudents;
  } catch {
    return initialStudents;
  }
}

function AppLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="logo-mark"><Sparkles size={18} strokeWidth={2.8} /></div>
      {!compact && <div className="leading-none"><div className="logo-word">English, Math and technology</div><div className="logo-sub">for Inclusion</div></div>}
    </div>
  );
}

function StatPill({ icon: Icon, value, label, tone }: { icon: typeof Star; value: string | number; label: string; tone: string }) {
  return <div className="stat-pill"><div className="stat-icon" style={{ background: tone }}><Icon size={16} fill="currentColor" /></div><div><strong>{value}</strong><span>{label}</span></div></div>;
}

function ProgressBar({ value, color = "#4b8df8" }: { value: number; color?: string }) {
  return <div className="progress-track"><div className="progress-fill" style={{ width: `${value}%`, background: color }} /></div>;
}

function Header({ view, setView, student, onTeacher }: { view: View; setView: (v: View) => void; student: Student; onTeacher: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  return <header className="topbar">
    <div className="topbar-inner">
      <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Abrir menu"><Menu size={22} /></button>
      <button className="brand-button" onClick={() => setView("inicio")}><AppLogo /></button>
      <nav className={menuOpen ? "main-nav open" : "main-nav"}>
        <button className={view === "inicio" ? "nav-link active" : "nav-link"} onClick={() => { setView("inicio"); setMenuOpen(false); }}><HomeIcon size={16} /> Início</button>
        <button className={view === "explorar" ? "nav-link active" : "nav-link"} onClick={() => { setView("explorar"); setMenuOpen(false); }}><Gamepad2 size={16} /> Explorar atividades</button>
        <button className={view === "perfil" ? "nav-link active" : "nav-link"} onClick={() => { setView("perfil"); setMenuOpen(false); }}><Award size={16} /> Meu perfil</button>
      </nav>
      <div className="header-actions">
        <div className="header-stat"><Flame size={17} fill="#ed7358" color="#ed7358" /><b>{student.streak}</b><span>dias</span></div>
        <div className="header-stat"><Star size={17} fill="#f1ae40" color="#f1ae40" /><b>{student.stars}</b></div>
        <button className="icon-button" aria-label="Notificações"><Bell size={19} /></button>
        <button className="avatar-button" onClick={() => setView("perfil")}><span>{student.avatar}</span></button>
      </div>
    </div>
  </header>;
}

function Hero({ student, startLearning, openChallenge }: { student: Student; startLearning: () => void; openChallenge: () => void }) {
  return <section className="hero-card">
    <div className="hero-copy">
      <div className="eyebrow"><span className="eyebrow-dot" /> quarta-feira, 08 de setembro</div>
      <h1>Olá, {student.name}!<br /><em>Pronto para brilhar?</em> <span className="wave">✦</span></h1>
      <p>Seu cantinho de descobertas está esperando por você. Que tal aprender brincando hoje?</p>
      <div className="hero-buttons"><Button className="primary-cta" onClick={startLearning}><Zap size={18} fill="currentColor" /> COMEÇAR A APRENDER <ArrowRight size={17} /></Button><button className="text-cta" onClick={openChallenge}>Ver desafio do dia <ChevronRight size={16} /></button></div>
    </div>
    <div className="hero-art"><div className="sunburst" /><div className="hero-star star-a">✦</div><div className="hero-star star-b">✦</div><div className="hero-doodle doodle-a" /><img src={MASCOT} alt="Mascote do site English, Math and technology for Inclusion" /><div className="hero-speech">Vamos aprender<br /><strong>juntos!</strong> <span>♡</span></div></div>
  </section>;
}

function ChallengeCard({ open }: { open: () => void }) {
  return <section className="challenge-card" onClick={open} role="button" tabIndex={0} onKeyDown={(e) => e.key === "Enter" && open()}>
    <div className="challenge-icon"><span>☀</span></div><div className="challenge-body"><div className="section-kicker coral">DESAFIO DO DIA <span>•</span> +20 estrelas</div><h3>Encontre as formas escondidas!</h3><p>Você consegue achar todas no jardim?</p><div className="challenge-bottom"><span className="mini-progress"><i style={{ width: "40%" }} /></span><small>2 de 5 pistas</small><ArrowRight size={17} /></div></div><div className="challenge-badge">novo!</div>
  </section>;
}

function SubjectCard({ subject, onClick }: { subject: Subject; onClick: () => void }) {
  const Icon = subject.icon;
  return <button className="subject-card" onClick={onClick} style={{ "--subject-color": subject.color, "--subject-soft": subject.soft } as React.CSSProperties}><div className="subject-icon"><Icon size={23} /></div><div className="subject-card-copy"><h3>{subject.label}</h3><p>{subject.subtitle}</p><ProgressBar value={subject.progress} color={subject.color} /></div><ChevronRight className="subject-arrow" size={17} /></button>;
}

function TraceBoard({ character, onComplete }: { character: string; onComplete: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawing = useRef(false);
  const [complete, setComplete] = useState(false);
  const coverage = () => { const canvas = canvasRef.current; if (!canvas) return 0; const ratio = window.devicePixelRatio || 1; const target = document.createElement("canvas"); target.width = canvas.width; target.height = canvas.height; const targetContext = target.getContext("2d"); const drawnContext = canvas.getContext("2d"); if (!targetContext || !drawnContext) return 0; targetContext.font = `900 ${174 * ratio}px Nunito, Arial`; targetContext.textAlign = "center"; targetContext.textBaseline = "middle"; targetContext.lineWidth = 10 * ratio; targetContext.strokeStyle = "#000"; targetContext.strokeText(character, canvas.width / 2, canvas.height / 2); const targetPixels = targetContext.getImageData(0, 0, canvas.width, canvas.height).data; const drawnPixels = drawnContext.getImageData(0, 0, canvas.width, canvas.height).data; let total = 0; let covered = 0; const stride = Math.max(3, Math.round(4 * ratio)); for (let y = 0; y < canvas.height; y += stride) for (let x = 0; x < canvas.width; x += stride) { const index = (y * canvas.width + x) * 4; if (targetPixels[index + 3] > 30) { total += 1; let found = false; for (let oy = -10; oy <= 10 && !found; oy += 2) for (let ox = -10; ox <= 10; ox += 2) { const px = Math.min(canvas.width - 1, Math.max(0, x + Math.round(ox * ratio))); const py = Math.min(canvas.height - 1, Math.max(0, y + Math.round(oy * ratio))); if (drawnPixels[(py * canvas.width + px) * 4 + 3] > 20) { found = true; break; } } if (found) covered += 1; } } return total ? covered / total : 0; };
  useEffect(() => { const canvas = canvasRef.current; if (!canvas) return; const rect = canvas.getBoundingClientRect(); const ratio = window.devicePixelRatio || 1; canvas.width = rect.width * ratio; canvas.height = rect.height * ratio; const context = canvas.getContext("2d"); if (!context) return; context.scale(ratio, ratio); context.lineCap = "round"; context.lineJoin = "round"; context.lineWidth = 12; context.strokeStyle = "#ed7358"; setComplete(false); }, [character]);
  const position = (event: React.PointerEvent<HTMLCanvasElement>) => { const rect = event.currentTarget.getBoundingClientRect(); return { x: event.clientX - rect.left, y: event.clientY - rect.top }; };
  const start = (event: React.PointerEvent<HTMLCanvasElement>) => { event.currentTarget.setPointerCapture(event.pointerId); const context = canvasRef.current?.getContext("2d"); if (!context) return; const point = position(event); context.beginPath(); context.moveTo(point.x, point.y); drawing.current = true; };
  const move = (event: React.PointerEvent<HTMLCanvasElement>) => { if (!drawing.current) return; const context = canvasRef.current?.getContext("2d"); if (!context) return; const point = position(event); context.lineTo(point.x, point.y); context.stroke(); if (!complete && coverage() >= 0.78) { setComplete(true); onComplete(); } };
  const stop = () => { drawing.current = false; };
  const clear = () => { const canvas = canvasRef.current; const context = canvas?.getContext("2d"); if (!canvas || !context) return; context.clearRect(0, 0, canvas.width, canvas.height); setComplete(false); };
  return <div className="trace-board-wrap"><div className="trace-board"><div className="trace-character" aria-hidden="true">{character}</div><canvas ref={canvasRef} onPointerDown={start} onPointerMove={move} onPointerUp={stop} onPointerCancel={stop} aria-label={`Cubra o caractere ${character}`} /></div><div className="trace-actions"><span>{complete ? "Muito bem! Você cobriu o desenho." : "Siga o pontilhado com o dedo ou mouse."}</span><button className="trace-clear" onClick={clear}><RotateCcw size={15} /> Apagar</button></div></div>;
}

function ActivityModal({ subject, level, completedIds, onClose, onComplete }: { subject: Subject; level: Level; completedIds: string[]; onClose: () => void; onComplete: (points: number, activityIds: string[]) => void }) {
  const [step, setStep] = useState(0);
  const [chosen, setChosen] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const activities = useMemo(() => {
    const pools: Record<string, Omit<Activity, "id">[]> = {
      matematica: [{ prompt: "Qual número vem depois?", visual: "2 · 4 · 6 · ?", options: ["7", "8", "9"], answer: "8" }, { prompt: "Quantas estrelinhas você vê?", visual: "★ ★ ★ ★", options: ["3", "4", "5"], answer: "4" }, { prompt: "Quanto é 3 + 2?", visual: "3 + 2 = ?", options: ["4", "5", "6"], answer: "5" }, { prompt: "Qual é o maior número?", visual: "6   9   4", options: ["4", "6", "9"], answer: "9" }, { prompt: "Complete a sequência", visual: "10 · 9 · 8 · ?", options: ["6", "7", "9"], answer: "7" }, { prompt: "Quanto é 5 - 2?", visual: "5 - 2 = ?", options: ["2", "3", "4"], answer: "3" }, { prompt: "Conte os balões", visual: "🎈 🎈 🎈 🎈 🎈", options: ["4", "5", "6"], answer: "5" }, { prompt: "Qual vem antes do 10?", visual: "8 · 9 · ? · 11", options: ["7", "10", "12"], answer: "10" }, { prompt: "Qual grupo tem mais?", visual: "🍎🍎🍎  |  🍎🍎", options: ["Primeiro", "Segundo", "Iguais"], answer: "Primeiro" }, { prompt: "Complete: 1, 3, 5, ?", visual: "1 · 3 · 5 · ?", options: ["6", "7", "8"], answer: "7" }],
      ingles: [{ prompt: "Which color is the sun?", visual: "☀️", options: ["BLUE", "YELLOW", "PINK"], answer: "YELLOW" }, { prompt: "Find the GREEN leaf", visual: "🍃", options: ["RED", "GREEN", "PURPLE"], answer: "GREEN" }, { prompt: "What number is TWO?", visual: "✌️", options: ["ONE", "TWO", "THREE"], answer: "TWO" }, { prompt: "Choose the color of the ocean", visual: "🌊", options: ["BLUE", "ORANGE", "BROWN"], answer: "BLUE" }, { prompt: "Complete: P _ NK", visual: "🌸", options: ["I", "A", "O"], answer: "I" }, { prompt: "How do you say gato?", visual: "🐱", options: ["DOG", "CAT", "BIRD"], answer: "CAT" }, { prompt: "Choose the GREEN fruit", visual: "🍏", options: ["GREEN", "PINK", "BLACK"], answer: "GREEN" }, { prompt: "What comes after ONE?", visual: "ONE, ?", options: ["TWO", "FOUR", "TEN"], answer: "TWO" }, { prompt: "Complete: B _ G", visual: "👜", options: ["A", "E", "I"], answer: "A" }, { prompt: "How do you say azul?", visual: "🔵", options: ["RED", "BLUE", "YELLOW"], answer: "BLUE" }],
      logica: [{ prompt: "Qual peça completa o padrão?", visual: "🔵 🟡 🔵 🟡 ?", options: ["🔵", "🟢", "🟣"], answer: "🔵" }, { prompt: "Encontre o diferente", visual: "🐶 🐶 🐱 🐶", options: ["🐶", "🐱", "🐰"], answer: "🐱" }, { prompt: "O que vem depois?", visual: "⭐ ⭐⭐ ⭐⭐⭐ ?", options: ["⭐⭐", "⭐⭐⭐⭐", "🌟"], answer: "⭐⭐⭐⭐" }, { prompt: "Qual sombra combina?", visual: "🍎 🍌 🍎 ?", options: ["🍌", "🍎", "🍇"], answer: "🍌" }, { prompt: "Complete as formas", visual: "▲ ■ ▲ ■ ?", options: ["●", "▲", "■"], answer: "▲" }, { prompt: "Qual é o intruso?", visual: "🔺 🔺 🔺 🟢", options: ["🔺", "🟢", "Todos"], answer: "🟢" }, { prompt: "Continue o padrão", visual: "🌞 🌙 🌞 ?", options: ["🌞", "🌙", "⭐"], answer: "🌙" }, { prompt: "Qual combina com a chave?", visual: "🔑 → 🔒", options: ["🚪", "☀️", "🍎"], answer: "🚪" }, { prompt: "Qual vem primeiro?", visual: "🐣 → ?", options: ["🐔", "🐟", "🐝"], answer: "🐔" }, { prompt: "Complete a sequência", visual: "● ●● ●●● ?", options: ["●", "●●●●", "▲"], answer: "●●●●" }],
      alfabetizacao: [{ prompt: "Qual é a primeira letra de MALA?", visual: "_ A L A", options: ["M", "P", "S"], answer: "M" }, { prompt: "Complete a palavra", visual: "C _ SA 🏠", options: ["A", "O", "U"], answer: "A" }, { prompt: "Combine a letra e a imagem", visual: "B → ?", options: ["🐱", "⚽", "🌙"], answer: "⚽" }, { prompt: "Qual letra falta na sequência?", visual: "A _ C D", options: ["B", "E", "F"], answer: "B" }, { prompt: "Organize as letras", visual: "A M O _", options: ["R", "S", "L"], answer: "R" }, { prompt: "Qual começa com P?", visual: "🐟", options: ["PEIXE", "CASA", "BOLA"], answer: "PEIXE" }, { prompt: "Complete: B _ LA", visual: "⚽", options: ["O", "A", "E"], answer: "O" }, { prompt: "Qual palavra rima com gato?", visual: "🐱", options: ["RATO", "MESA", "SOL"], answer: "RATO" }, { prompt: "Qual é a última letra de SOL?", visual: "S O _", options: ["A", "L", "O"], answer: "L" }, { prompt: "Junte as sílabas", visual: "CA + _ A = ?", options: ["S", "M", "L"], answer: "S" }],
      musica: [{ prompt: "Que animal faz este som?", visual: "🐶", sound: "dog", options: ["Cachorro", "Gato", "Vaca"], answer: "Cachorro" }, { prompt: "Que animal faz este som?", visual: "🐱", sound: "cat", options: ["Passarinho", "Gato", "Cavalo"], answer: "Gato" }, { prompt: "Que animal faz este som?", visual: "🐸", sound: "frog", options: ["Sapo", "Gato", "Vaca"], answer: "Sapo" }, { prompt: "Que animal faz este som?", visual: "🐮", sound: "cow", options: ["Vaca", "Cachorro", "Leão"], answer: "Vaca" }, { prompt: "Que animal faz este som?", visual: "🐦", sound: "bird", options: ["Gato", "Passarinho", "Ovelha"], answer: "Passarinho" }, { prompt: "Qual instrumento ouvimos?", visual: "🥁", sound: "drum", options: ["Tambor", "Piano", "Flauta"], answer: "Tambor" }, { prompt: "Qual instrumento ouvimos?", visual: "🎹", sound: "piano", options: ["Violão", "Piano", "Sino"], answer: "Piano" }, { prompt: "Qual instrumento ouvimos?", visual: "🎸", sound: "guitar", options: ["Flauta", "Violão", "Tambor"], answer: "Violão" }, { prompt: "Qual instrumento ouvimos?", visual: "🎺", sound: "trumpet", options: ["Piano", "Trompete", "Sino"], answer: "Trompete" }, { prompt: "Qual instrumento ouvimos?", visual: "🔔", sound: "bell", options: ["Sino", "Violão", "Flauta"], answer: "Sino" }],
      caligrafia: ["A", "B", "C", "D", "E", "1", "2", "3", "4", "5"].map((character) => ({ prompt: `Cubra o ${/[0-9]/.test(character) ? "número" : "letra"} ${character}`, visual: character, trace: character, options: [], answer: "traced" })),
    };
    const base = pools[subject.key] ?? pools.alfabetizacao;
    return base.map((activity, index) => ({ ...activity, id: `${subject.key}-${level}-${index}` }));
  }, [subject.key, level]);
  const availableActivities = activities.filter((activity) => !completedIds.includes(activity.id)).slice(0, 5);
  const playableActivities = availableActivities;
  const noMoreActivities = playableActivities.length === 0;
  const current = playableActivities[step] || activities[0];
  const select = (option: string) => { setChosen(option); };
  const playSound = (kind?: string) => { if (!kind) return; const AudioContextClass = window.AudioContext || (window as typeof window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext; if (!AudioContextClass) return; const audio = new AudioContextClass(); const now = audio.currentTime; const master = audio.createGain(); master.gain.value = 0.7; master.connect(audio.destination);
    const tone = (frequency: number, start: number, duration: number, type: OscillatorType = "sine", volume = 0.25, endFrequency?: number) => { const oscillator = audio.createOscillator(); const gain = audio.createGain(); oscillator.type = type; oscillator.frequency.setValueAtTime(frequency, now + start); if (endFrequency) oscillator.frequency.exponentialRampToValueAtTime(endFrequency, now + start + duration); gain.gain.setValueAtTime(0.001, now + start); gain.gain.linearRampToValueAtTime(volume, now + start + 0.025); gain.gain.exponentialRampToValueAtTime(0.001, now + start + duration); oscillator.connect(gain); gain.connect(master); oscillator.start(now + start); oscillator.stop(now + start + duration + 0.03); };
    const noise = (start: number, duration: number, volume = 0.22) => { const buffer = audio.createBuffer(1, Math.ceil(audio.sampleRate * duration), audio.sampleRate); const data = buffer.getChannelData(0); for (let i = 0; i < data.length; i += 1) data[i] = Math.random() * 2 - 1; const source = audio.createBufferSource(); const filter = audio.createBiquadFilter(); const gain = audio.createGain(); filter.type = "bandpass"; filter.frequency.value = 900; filter.Q.value = 0.8; gain.gain.setValueAtTime(0.001, now + start); gain.gain.linearRampToValueAtTime(volume, now + start + 0.01); gain.gain.exponentialRampToValueAtTime(0.001, now + start + duration); source.buffer = buffer; source.connect(filter); filter.connect(gain); gain.connect(master); source.start(now + start); };
    if (kind === "dog") { const bark = (start: number, base: number) => { noise(start, 0.12, 0.34); tone(base, start, 0.18, "sawtooth", 0.17, base * 0.62); tone(base * 2.2, start + 0.015, 0.13, "triangle", 0.07, base * 1.25); }; bark(0, 170); bark(0.28, 205); }
    else if (kind === "cat") { tone(680, 0, 0.34, "sawtooth", 0.13, 980); tone(980, 0.32, 0.7, "sawtooth", 0.16, 300); tone(1360, 0.34, 0.45, "triangle", 0.06, 520); }
    else if (kind === "frog") { noise(0, 0.28, 0.16); tone(170, 0, 0.18, "square", 0.18, 125); tone(145, 0.22, 0.2, "square", 0.18, 105); tone(125, 0.46, 0.24, "square", 0.16, 88); }
    else if (kind === "cow") { tone(138, 0, 0.2, "sawtooth", 0.17, 112); tone(118, 0.19, 1.05, "sawtooth", 0.25, 76); tone(236, 0.22, 0.9, "triangle", 0.08, 150); }
    else if (kind === "bird") { tone(950, 0, 0.18, "sine", 0.14, 1650); tone(1480, 0.2, 0.2, "sine", 0.16, 1080); tone(1100, 0.43, 0.26, "sine", 0.15, 1950); tone(1750, 0.71, 0.32, "sine", 0.13, 1200); }
    else if (kind === "horse") { noise(0, 0.14, 0.38); tone(280, 0, 0.18, "square", 0.13, 150); noise(0.24, 0.12, 0.35); tone(240, 0.24, 0.17, "square", 0.13, 120); noise(0.48, 0.1, 0.3); }
    else if (kind === "drum") { noise(0, 0.28, 0.6); tone(110, 0, 0.18, "triangle", 0.24, 55); }
    else if (kind === "piano") { tone(262, 0, 0.8, "triangle", 0.22); tone(330, 0.18, 0.8, "triangle", 0.2); tone(392, 0.36, 0.95, "triangle", 0.18); }
    else if (kind === "guitar") { tone(196, 0, 0.75, "sawtooth", 0.13); tone(247, 0.04, 0.7, "triangle", 0.12); tone(294, 0.08, 0.62, "triangle", 0.1); }
    else if (kind === "trumpet") { tone(233, 0, 0.75, "sawtooth", 0.2, 294); tone(294, 0.04, 0.7, "square", 0.1, 349); }
    else if (kind === "bell") { tone(784, 0, 1.3, "sine", 0.25); tone(1047, 0.02, 1.0, "sine", 0.13); }
    else tone(440, 0, 0.4); window.setTimeout(() => void audio.close(), 2200); };
  const next = () => { if (!chosen) return; if (chosen === current.answer) { if (step === playableActivities.length - 1) { setDone(true); onComplete(rewardForLevel(level), playableActivities.map((activity) => activity.id)); } else { setStep(step + 1); setChosen(null); } } else { toast("Quase! Tente mais uma vez 💛"); setChosen(null); } };
  return <div className="modal-backdrop"><div className="game-modal">
    <div className="game-top"><button className="icon-button muted" onClick={onClose} aria-label="Fechar atividade"><X size={20} /></button><div className="game-title"><span style={{ background: subject.soft, color: subject.color }}><subject.icon size={19} /></span><div><small>{subject.label} • {level}</small><h2>{subject.activity}</h2></div></div><div className="game-counter">{done ? "✓" : `${step + 1}/${playableActivities.length}`}</div></div>
    {noMoreActivities ? <div className="game-complete"><div className="complete-burst">🏆</div><h2>Você completou este nível!</h2><p>Todos os desafios disponíveis já foram concluídos. Escolha outro nível ou outra trilha para continuar descobrindo.</p><Button className="primary-cta" onClick={onClose}>Escolher outra atividade <ArrowRight size={17} /></Button></div> : done ? <div className="game-complete"><div className="complete-burst">🎉</div><h2>Você conseguiu!</h2><p>Atividade concluída e <strong>+{rewardForLevel(level)} estrelas</strong> para você.</p><div className="confetti-line">✦　★　✦　★　✦</div><Button className="primary-cta" onClick={onClose}>Voltar para aprender <ArrowRight size={17} /></Button></div> : <div className="game-body"><div className="game-progress"><span style={{ width: `${((step) / playableActivities.length) * 100}%`, background: subject.color }} /></div><div className="game-prompt"><div className="prompt-label">MISSÃO {step + 1}</div><h3>{current.prompt}</h3>{current.trace ? <TraceBoard character={current.trace} onComplete={() => setChosen("traced")} /> : <><div className="visual-question">{current.visual}</div>{current.sound && <button className="sound-button" onClick={() => playSound(current.sound)}><Volume2 size={18} /> Ouvir o som novamente</button>}</>}</div>{current.trace ? <p className="game-hint"><Pencil size={15} /> Cubra toda a letra ou número para liberar a próxima missão.</p> : <><div className="answer-grid">{current.options.map((option) => <button key={option} className={chosen === option ? "answer selected" : "answer"} onClick={() => select(option)}>{option}{chosen === option && <Check size={17} />}</button>)}</div><p className="game-hint"><Lightbulb size={15} /> Dica: ouça com atenção e pense com calma!</p></>}<Button className="next-answer" disabled={!chosen} onClick={next}>{step === playableActivities.length - 1 ? "Concluir atividade" : "Próxima"} <ArrowRight size={17} /></Button></div>}
  </div></div>;
}

function LevelPicker({ subject, completedActivities, onStart, onClose }: { subject: Subject; completedActivities: Record<string, string[]>; onStart: (level: Level) => void; onClose: () => void }) {
  const completedFor = (level: Level) => completedActivities[`${subject.key}:${level}`] || [];
  const unlocked = (index: number) => index === 0 || completedFor(levels[index - 1].name).length >= 10;
  const choose = (level: Level, index: number) => { if (unlocked(index)) onStart(level); else toast("Complete todas as atividades do nível anterior para desbloquear este nível! ⭐"); };
  return <div className="modal-backdrop"><div className="level-modal"><button className="icon-button muted close-level" onClick={onClose} aria-label="Fechar"><X size={20} /></button><div className="level-heading"><div className="level-subject-icon" style={{ color: subject.color, background: subject.soft }}><subject.icon size={27} /></div><div><div className="section-kicker" style={{ color: subject.color }}>HORA DE APRENDER</div><h2>{subject.label}</h2><p>Complete uma fase para liberar a próxima.</p></div></div><div className="levels-list">{levels.map((level, index) => { const isUnlocked = unlocked(index); const completedCount = completedFor(level.name).length; return <button className={isUnlocked ? "level-option" : "level-option locked-option"} key={level.name} onClick={() => choose(level.name, index)}><span className="level-dot" style={{ color: level.color }}>{level.icon}</span><span className="level-text"><b>{level.name}</b><small>{isUnlocked ? `${completedCount}/10 desafios concluídos · ${level.note}` : `Bloqueado · conclua ${levels[index - 1].name}`}</small></span>{isUnlocked ? <span className="play-pill">Jogar <ArrowRight size={15} /></span> : <LockKeyhole size={17} className="locked" />}</button>; })}</div><p className="level-footnote"><Sparkles size={14} /> Ao concluir 10 desafios, o próximo nível é liberado</p></div></div>;
}

function HomeDashboard({ student, setView, openSubject, openChallenge, openTeacher }: { student: Student; setView: (v: View) => void; openSubject: (s: Subject) => void; openChallenge: () => void; openTeacher: () => void }) {
  return <main className="page-wrap"><Hero student={student} startLearning={() => setView("explorar")} openChallenge={openChallenge} /><div className="dashboard-grid"><div className="main-column"><div className="section-heading"><div><div className="section-kicker">CONTINUE DE ONDE PAROU</div><h2>Suas trilhas de descoberta</h2></div><button className="view-all" onClick={() => setView("explorar")}>Ver todas <ChevronRight size={15} /></button></div><div className="subject-grid">{subjects.slice(0, 6).map((subject) => <SubjectCard key={subject.key} subject={subject} onClick={() => openSubject(subject)} />)}</div><div className="section-heading second"><div><div className="section-kicker">PARA VOCÊ HOJE</div><h2>Atividades recomendadas</h2></div></div><div className="recommendation-row"><button className="recommend-card recommend-blue" onClick={() => openSubject(subjects[4])}><div className="rec-icon">Aa</div><div><strong>Uma palavrinha em inglês</strong><p>5 min · fácil</p></div><ArrowRight size={18} /></button><button className="recommend-card recommend-yellow" onClick={() => openSubject(subjects[3])}><div className="rec-icon">✎</div><div><strong>Desenhe seu próprio jardim</strong><p>10 min · criativo</p></div><ArrowRight size={18} /></button></div></div><aside className="side-column"><div className="profile-mini"><div className="profile-mini-top"><div className="big-avatar">{student.avatar}</div><div><small>MEU PERFIL</small><h3>{student.name}</h3><p>Nível explorador ✦</p></div><button className="icon-button muted" onClick={() => setView("perfil")}><Edit3 size={16} /></button></div><div className="profile-progress-row"><div><span>Progresso geral</span><strong>{student.progress}%</strong></div><ProgressBar value={student.progress} color="#35b896" /></div><div className="profile-stats"><div><Star size={16} fill="#f1ae40" color="#f1ae40" /><b>{student.stars}</b><small>estrelas</small></div><div><Trophy size={16} color="#ed7358" /><b>3</b><small>medalhas</small></div><div><Zap size={16} fill="#4b8df8" color="#4b8df8" /><b>{student.points}</b><small>pontos</small></div></div></div><ChallengeCard open={openChallenge} /><div className="teacher-card"><div className="teacher-icon"><GraduationCap size={21} /></div><div><strong>Área do professor</strong><p>Acompanhe seu progresso</p></div><button onClick={openTeacher} aria-label="Abrir área do professor"><ChevronRight size={18} /></button></div></aside></div></main>;
}

function ExploreView({ openSubject }: { openSubject: (s: Subject) => void }) {
  const [filter, setFilter] = useState("Todos");
  const filtered = filter === "Todos" ? subjects : subjects.filter((s) => s.key === filter);
  return <main className="page-wrap inner-page"><div className="inner-heading"><div><div className="section-kicker">MAPA DE AVENTURAS</div><h1>O que vamos descobrir?</h1><p>Escolha uma trilha e avance no seu ritmo. Cada trilha tem 15 atividades divertidas.</p></div><div className="explore-sticker">🗺️</div></div><div className="filter-row"><button className={filter === "Todos" ? "filter active" : "filter"} onClick={() => setFilter("Todos")}>Todas as trilhas</button>{subjects.slice(0, 5).map((s) => <button key={s.key} className={filter === s.key ? "filter active" : "filter"} onClick={() => setFilter(s.key)}>{s.label}</button>)}</div><div className="explore-grid">{filtered.map((subject) => <div className="explore-card" key={subject.key}><div className="explore-card-top" style={{ background: subject.soft }}><div className="explore-icon" style={{ color: subject.color }}><subject.icon size={28} /></div><span className="activity-count">15 atividades</span></div><div className="explore-card-body"><h3>{subject.label}</h3><p>{subject.subtitle}. Aprenda brincando com desafios que ficam mais interessantes a cada nível.</p><div className="explore-meta"><span><Check size={14} /> {Math.round(subject.progress / 20)} concluídas</span><span style={{ color: subject.color }}>{subject.progress}%</span></div><ProgressBar value={subject.progress} color={subject.color} /><button className="explore-play" onClick={() => openSubject(subject)}>Explorar trilha <ArrowRight size={16} /></button></div></div>)}</div></main>;
}

function ProfileView({ student, setView, onEditName }: { student: Student; setView: (v: View) => void; onEditName: () => void }) {
  return <main className="page-wrap inner-page"><div className="profile-page-head"><button className="back-link" onClick={() => setView("inicio")}><ArrowLeft size={16} /> Voltar para início</button><div className="profile-hero"><div className="profile-avatar-large">{student.avatar}</div><div><div className="section-kicker">MEU CANTINHO</div><h1>{student.name}</h1><p>Explorador(a) de nível 4 · aprendendo todos os dias ✦</p></div><Button className="outline-button" onClick={onEditName}><Edit3 size={16} /> Alterar meu nome</Button></div></div><div className="profile-layout"><section className="profile-main-card"><div className="card-head"><div><h2>Minha jornada</h2><p>Olha quanta coisa você já descobriu!</p></div><div className="level-medal">4</div></div><div className="journey-line"><div className="journey-complete"><Check size={15} /></div><div className="journey-copy"><b>Primeiros passos</b><small>Você começou a explorar</small></div><div className="journey-connector done" /><div className="journey-complete"><Check size={15} /></div><div className="journey-copy"><b>Curioso</b><small>10 atividades concluídas</small></div><div className="journey-connector active" /><div className="journey-current"><span>✦</span></div><div className="journey-copy"><b>Descobridor</b><small>Seu momento atual</small></div></div><div className="subjects-progress"><h3>Progresso por trilha</h3>{subjects.slice(0, 5).map((s) => <div className="subject-progress-row" key={s.key}><div className="subject-progress-icon" style={{ color: s.color, background: s.soft }}><s.icon size={16} /></div><span>{s.label}</span><ProgressBar value={s.progress} color={s.color} /><b style={{ color: s.color }}>{s.progress}%</b></div>)}</div></section><aside className="profile-side-card"><div className="section-kicker">MINHAS CONQUISTAS</div><div className="trophy-total"><Trophy size={30} color="#f1ae40" /><div><strong>3</strong><span>medalhas</span></div></div><div className="badge-row"><div className="badge-item earned">🔥<span>Sequência<br />de 4 dias</span></div><div className="badge-item earned">🌟<span>Primeira<br />estrela</span></div><div className="badge-item locked">🔒<span>Em breve<br />novo desafio</span></div></div><div className="profile-tip"><Heart size={17} fill="currentColor" /> Continue assim! Seu brilho está aumentando.</div></aside></div></main>;
}

function NameSetupModal({ currentName, currentAvatar, onSave, onClose }: { currentName: string; currentAvatar: string; onSave: (name: string, avatar: string) => void; onClose?: () => void }) {
  const [name, setName] = useState(currentName);
  const [avatar, setAvatar] = useState(currentAvatar);
  const save = () => { const clean = name.trim(); if (clean) onSave(clean, avatar); };
  return <div className="modal-backdrop"><div className="add-student-modal name-setup-modal">{onClose && <button className="icon-button muted close-level" onClick={onClose} aria-label="Fechar"><X size={20} /></button>}<div className="level-heading"><div className="level-subject-icon teacher-color"><Sparkles size={26} /></div><div><div className="section-kicker">SEU CANTINHO</div><h2>Como podemos te chamar?</h2><p>Escolha seu personagem e personalize sua aventura.</p></div></div><label>Meu nome<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Sofia" autoFocus onKeyDown={(e) => e.key === "Enter" && save()} /></label><label>Meu personagem</label><div className="avatar-picker">{avatars.map((item) => <button type="button" key={item} className={avatar === item ? "picked" : ""} onClick={() => setAvatar(item)} aria-label={`Escolher personagem ${item}`}>{item}</button>)}</div><Button className="primary-cta full" onClick={save} disabled={!name.trim()}>Continuar <ArrowRight size={17} /></Button></div></div>;
}

function TeacherView({ students, setStudents, onBack, onSelectStudent }: { students: Student[]; setStudents: (s: Student[]) => void; onBack: () => void; onSelectStudent: (s: Student) => void }) {
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState("🧑‍🚀");
  const add = () => { if (!name.trim()) return; const student = { id: Date.now().toString(), name: name.trim(), avatar, points: 0, stars: 0, progress: 0, streak: 0 }; const next = [...students, student]; setStudents(next); localStorage.setItem("lumina-students", JSON.stringify(next)); setName(""); setAdding(false); toast.success(`${student.name} foi cadastrado!`); };
  return <main className="page-wrap teacher-page"><div className="teacher-heading"><div><button className="back-link" onClick={onBack}><ArrowLeft size={16} /> Voltar para a plataforma</button><div className="section-kicker">PAINEL DO PROFESSOR</div><h1>Olá, professor! <span>Vamos acompanhar?</span></h1><p>Veja como seus alunos estão avançando e celebre cada descoberta.</p></div><div className="teacher-heading-icon"><GraduationCap size={36} /></div></div><div className="teacher-summary"><div><span>Alunos ativos</span><strong>{students.length}</strong><small><ArrowRight size={13} /> este mês</small></div><div><span>Atividades concluídas</span><strong>{students.reduce((sum, s) => sum + Math.round(s.progress / 20), 0)}</strong><small className="up"><ArrowRight size={13} /> evolução da turma</small></div><div><span>Estrelas da turma</span><strong>{students.reduce((sum, s) => sum + s.stars, 0)}</strong><small className="up"><ArrowRight size={13} /> total conquistado</small></div><div className="summary-sparkle">✦</div></div><div className="teacher-toolbar"><div><h2>Minha turma</h2><p>Todos os alunos cadastrados e o desenvolvimento de cada um.</p></div><Button className="primary-cta" onClick={() => setAdding(true)}><Plus size={18} /> Cadastrar aluno</Button></div><div className="student-table"><div className="table-head"><span>ALUNO</span><span>PROGRESSO GERAL</span><span>ÚLTIMA ATIVIDADE</span><span>STATUS</span><span /></div>{students.map((s) => <button className="student-row" key={s.id} onClick={() => onSelectStudent(s)}><div className="student-name"><span className="student-avatar">{s.avatar}</span><span><b>{s.name}</b><small>Nível {Math.max(1, Math.floor(s.progress / 25))} · {s.points} pontos · {s.stars} estrelas</small></span></div><div className="row-progress"><div><ProgressBar value={s.progress} color={s.progress > 75 ? "#35b896" : "#4b8df8"} /><b>{s.progress}%</b></div></div><div className="last-activity"><Clock3 size={15} /> hoje, 09:24</div><div className="student-status"><span /> Aprendendo</div><ChevronRight size={18} className="row-arrow" /></button>)}</div>{adding && <div className="modal-backdrop"><div className="add-student-modal"><button className="icon-button muted close-level" onClick={() => setAdding(false)}><X size={20} /></button><div className="level-heading"><div className="level-subject-icon teacher-color"><Plus size={26} /></div><div><div className="section-kicker">NOVO PERFIL</div><h2>Cadastrar aluno</h2><p>Nome, personagem e desenvolvimento em um só lugar.</p></div></div><label>Nome do aluno<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex.: Sofia" autoFocus /></label><label>Escolha um personagem</label><div className="avatar-picker">{avatars.map((a) => <button type="button" key={a} className={avatar === a ? "picked" : ""} onClick={() => setAvatar(a)}>{a}</button>)}</div><Button className="primary-cta full" onClick={add} disabled={!name.trim()}>Criar perfil <ArrowRight size={17} /></Button></div></div>}</main>;
}

function StudentDetail({ student, onBack }: { student: Student; onBack: () => void }) {
  return <main className="page-wrap inner-page"><button className="back-link" onClick={onBack}><ArrowLeft size={16} /> Voltar para turma</button><div className="student-detail-head"><div className="profile-avatar-large">{student.avatar}</div><div><div className="section-kicker">PERFIL DO ALUNO</div><h1>{student.name}</h1><p>Última atividade hoje às 09:24 · sequência de {student.streak} dias</p></div><div className="detail-actions"><Button className="outline-button"><Edit3 size={16} /> Editar perfil</Button><Button className="primary-cta"><Award size={16} /> Liberar nível</Button></div></div><div className="detail-metrics"><div><span>Pontos</span><strong>{student.points}</strong></div><div><span>Estrelas</span><strong>{student.stars} ⭐</strong></div><div><span>Atividades</span><strong>{Math.round(student.progress / 20)} / 15</strong></div><div><span>Desempenho</span><strong>{student.progress}%</strong></div></div><div className="detail-content"><section className="profile-main-card"><div className="card-head"><div><h2>Desempenho por matéria</h2><p>Uma visão geral da jornada de {student.name}.</p></div><BarChart3 size={21} color="#4b8df8" /></div>{subjects.slice(0, 5).map((s, i) => <div className="subject-progress-row detail-row" key={s.key}><div className="subject-progress-icon" style={{ color: s.color, background: s.soft }}><s.icon size={16} /></div><span>{s.label}</span><ProgressBar value={Math.max(20, Math.min(100, student.progress + 4 - i * 8))} color={s.color} /><b style={{ color: s.color }}>{Math.max(20, Math.min(100, student.progress + 4 - i * 8))}%</b></div>)}</section><section className="teacher-note"><div className="note-icon"><CircleHelp size={21} /></div><h3>Uma observação</h3><p>“{student.name} está se destacando em desafios de lógica. Incentive a explorar também as atividades de inglês!”</p><button>Adicionar observação <Plus size={15} /></button></section></div></main>;
}

export default function Home() {
  const [view, setView] = useState<View>("inicio");
  const [students, setStudents] = useState<Student[]>(initialStudents);
  const [activeStudent, setActiveStudent] = useState<Student>(() => { try { const saved = localStorage.getItem("lumina-current-student"); return saved ? JSON.parse(saved) as Student : { ...defaultStudent, name: "" }; } catch { return { ...defaultStudent, name: "" }; } });
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<Level | null>(null);
  const [detailStudent, setDetailStudent] = useState<Student | null>(null);
  const [showNameSetup, setShowNameSetup] = useState(() => !localStorage.getItem("lumina-child-name"));
  const [completedActivities, setCompletedActivities] = useState<Record<string, string[]>>(() => { try { return JSON.parse(localStorage.getItem("lumina-completed-activities") || "{}") as Record<string, string[]>; } catch { return {}; } });
  useEffect(() => { setStudents(readStudents()); }, []);
  useEffect(() => { localStorage.setItem("lumina-current-student", JSON.stringify(activeStudent)); }, [activeStudent]);
  const openSubject = (subject: Subject) => setSelectedSubject(subject);
  const activityKey = selectedSubject && selectedLevel ? `${activeStudent.id}:${selectedSubject.key}:${selectedLevel}` : "";
  const saveChildName = (name: string, avatar: string) => { const updated = { ...activeStudent, name, avatar }; setActiveStudent(updated); setStudents((current) => { const next = current.some((s) => s.id === updated.id) ? current.map((s) => s.id === updated.id ? updated : s) : [...current, updated]; localStorage.setItem("lumina-students", JSON.stringify(next)); return next; }); localStorage.setItem("lumina-child-name", name); setShowNameSetup(false); toast.success(`Tudo certo, ${name}! ✨`); };
  const finishActivity = (points: number) => { const updated = { ...activeStudent, points: activeStudent.points + points, stars: activeStudent.stars + 5, progress: Math.min(100, activeStudent.progress + 2), streak: Math.max(4, activeStudent.streak) }; setActiveStudent(updated); setStudents(students.map((s) => s.id === updated.id ? updated : s)); localStorage.setItem("lumina-students", JSON.stringify(students.map((s) => s.id === updated.id ? updated : s))); toast.success(`Muito bem, ${updated.name}! +${points} pontos ✨`); };
  const finishActivityWithHistory = (points: number, activityIds: string[]) => { finishActivity(points); setCompletedActivities((current) => { const next = { ...current, [activityKey]: Array.from(new Set([...(current[activityKey] || []), ...activityIds])) }; localStorage.setItem("lumina-completed-activities", JSON.stringify(next)); return next; }); };
  const startLevel = (level: Level) => { setSelectedLevel(level); };
  const levelHistory = selectedSubject ? Object.fromEntries(levels.map((level) => [`${selectedSubject.key}:${level.name}`, completedActivities[`${activeStudent.id}:${selectedSubject.key}:${level.name}`] || []])) : {};
  return <div className="app-shell"><Header view={view} setView={setView} student={activeStudent} onTeacher={() => setView("professor")} />{view === "inicio" && <HomeDashboard student={activeStudent} setView={setView} openSubject={openSubject} openChallenge={() => openSubject(subjects[2])} openTeacher={() => setView("professor")} />}{view === "explorar" && <ExploreView openSubject={openSubject} />}{view === "perfil" && <ProfileView student={activeStudent} setView={setView} onEditName={() => setShowNameSetup(true)} />}{view === "professor" && !detailStudent && <TeacherView students={students} setStudents={setStudents} onBack={() => setView("inicio")} onSelectStudent={setDetailStudent} />}{view === "professor" && detailStudent && <StudentDetail student={detailStudent} onBack={() => setDetailStudent(null)} />}<footer className="footer"><AppLogo compact /><span>Feito para pequenos grandes descobridores.</span><span className="footer-right">sons opcionais <Volume2 size={14} /> · acessível para todos</span></footer>{showNameSetup && <NameSetupModal currentName={activeStudent.name} currentAvatar={activeStudent.avatar} onSave={saveChildName} onClose={activeStudent.name ? () => setShowNameSetup(false) : undefined} />}{selectedSubject && !selectedLevel && <LevelPicker subject={selectedSubject} completedActivities={levelHistory} onStart={startLevel} onClose={() => setSelectedSubject(null)} />}{selectedSubject && selectedLevel && <ActivityModal subject={selectedSubject} level={selectedLevel} completedIds={completedActivities[activityKey] || []} onClose={() => { setSelectedSubject(null); setSelectedLevel(null); }} onComplete={finishActivityWithHistory} />}</div>;
}
