export type LuminaLevel = "Iniciante" | "Médio" | "Avançado";

export function rewardForLevel(level: LuminaLevel) {
  if (level === "Avançado") return 35;
  if (level === "Médio") return 25;
  return 20;
}

export function nextStudentProgress(progress: number, stars: number, points: number, level: LuminaLevel) {
  return {
    progress: Math.min(100, progress + 2),
    stars: stars + 5,
    points: points + rewardForLevel(level),
  };
}
