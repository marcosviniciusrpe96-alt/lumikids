import { describe, expect, it } from "vitest";
import { nextStudentProgress, rewardForLevel } from "../shared/lumina";

describe("Lumina learning rewards", () => {
  it("awards progressively larger rewards by level", () => {
    expect(rewardForLevel("Iniciante")).toBe(20);
    expect(rewardForLevel("Médio")).toBe(25);
    expect(rewardForLevel("Avançado")).toBe(35);
  });

  it("updates points, stars, and progress without exceeding 100%", () => {
    expect(nextStudentProgress(99, 48, 1240, "Avançado")).toEqual({
      progress: 100,
      stars: 53,
      points: 1275,
    });
  });
});
